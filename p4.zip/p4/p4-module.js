let data = [
    { question: "Q1", answer: "A1" },
    { question: "Q2", answer: "A2" },
    { question: "Q3", answer: "A3" },
  ];
  
  function getQuestions() {
    return data.map((item) => item.question);
  }
  
  function getAnswers() {
    return data.map((item) => item.answer);
  }
  
  function getQuestionsAnswers() {
    return [...data];
  }
  
  function getQuestion(number = "") {
    const index = parseInt(number) - 1;
    if (isNaN(index)) {
      return {
        question: "",
        number: "",
        error: "Question number must be an integer",
      };
    }
    if (index < 0) {
      return {
        question: "",
        number: "",
        error: "Question number must be >= 1",
      };
    }
    if (index >= data.length) {
      return {
        question: "",
        number: "",
        error: `Question number must be less than the number of questions (${data.length})`,
      };
    }
    return {
      question: data[index].question,
      number: index + 1,
      error: "",
    };
  }
  
  function getAnswer(number = "") {
    const index = parseInt(number) - 1;
    if (isNaN(index)) {
      return {
        answer: "",
        number: "",
        error: "Answer number must be an integer",
      };
    }
    if (index < 0) {
      return {
        answer: "",
        number: "",
        error: "Answer number must be >= 1",
      };
    }
    if (index >= data.length) {
      return {
        answer: "",
        number: "",
        error: `Answer number must be less than the number of questions (${data.length})`,
      };
    }
    return {
      answer: data[index].answer,
      number: index + 1,
      error: "",
    };
  }
  
  function getQuestionAnswer(number = "") {
    const index = parseInt(number) - 1;
    if (isNaN(index)) {
      return {
        question: "",
        answer: "",
        number: "",
        error: "Question number must be an integer",
      };
    }
    if (index < 0) {
      return {
        question: "",
        answer: "",
        number: "",
        error: "Question number must be >= 1",
      };
    }
    if (index >= data.length) {
      return {
        question: "",
        answer: "",
        number: "",
        error: `Question number must be less than the number of questions (${data.length})`,
      };
    }
    return {
      question: data[index].question,
      answer: data[index].answer,
      number: index + 1,
      error: "",
    };
  }
  
  function getAllQuestionAnswers() {
    return data;
  }
  
  function createQuestionAnswer(info = {}) {
    if (!info.question || !info.answer) {
      return { error: "Both question and answer properties are required", number: "" };
    }
  
    data.push({ question: info.question, answer: info.answer });
    return { error: "", message: `Question ${data.length} created`, number: data.length };
  }
  
  module.exports = {
    getQuestions,
    getAnswers,
    getQuestionsAnswers,
    getQuestion,
    getAnswer,
    getQuestionAnswer,
    createQuestionAnswer,
  };