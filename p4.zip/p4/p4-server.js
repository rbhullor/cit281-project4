const fastify = require('fastify')();

const {
  getQuestions,
  getAnswers,
  getQuestionsAnswers,
  getQuestion,
  getAnswer,
  getQuestionAnswer,
} = require('./p4-module');

// Route: /cit/question
fastify.get('/cit/question', (req, res) => {
  res.status(200).send({
    error: "",
    statusCode: 200,
    questions: getQuestions(),
  });
});

// Route: /cit/answer
fastify.get('/cit/answer', (req, res) => {
  res.status(200).send({
    error: "",
    statusCode: 200,
    answers: getAnswers(),
  });
});

// Route: /cit/question-answer
fastify.get('/cit/question-answer', (req, res) => {
  res.status(200).send({
    error: "",
    statusCode: 200,
    questionAnswers: getQuestionsAnswers(),
  });
});

// Route: /cit/question/:number
fastify.get('/cit/question/:number', (req, res) => {
  const number = req.params.number;
  const question = getQuestion(number);
  res.status(200).send({
    error: question.error,
    statusCode: question.error ? 400 : 200,
    question: question.question,
    number: question.number,
  });
});

// Route: /cit/answer/:number
fastify.get('/cit/answer/:number', (req, res) => {
  const number = req.params.number;
  const answer = getAnswer(number);
  res.status(200).send({
    error: answer.error,
    statusCode: answer.error ? 400 : 200,
    answer: answer.answer,
    number: answer.number,
  });
});

// Route: /cit/question-answer/:number
fastify.get('/cit/question-answer/:number', (req, res) => {
  const number = req.params.number;
  const questionAnswer = getQuestionAnswer(number);
  res.status(200).send({
    error: questionAnswer.error,
    statusCode: questionAnswer.error ? 400 : 200,
    question: questionAnswer.question,
    answer: questionAnswer.answer,
    number: questionAnswer.number,
  });
});

fastify.listen(3000, (err) => {
  if (err) {
    console.log(err);
    process.exit(1);
  }
  console.log('Server is running on port 3000');
});
